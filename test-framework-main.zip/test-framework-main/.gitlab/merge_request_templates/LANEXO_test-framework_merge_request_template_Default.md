## Overview

### What is the feature/fix?

<!-- Describe the feature that was developed -->

### What is the solution?

<!-- Describe your solution -->

### What are the affected parts?

<!--
    If there are any dependencies that require an update,
    API changes or behavioural differences, mention them here -->

## Other Notes

<!-- Add any additional information that would be useful to the developer or reviewer -->

### Developer checklist

-   [ ] Mark Jira ticket as 'Ready'
-   [ ] Ensure branch name follows the pattern `lan-1234-my-new-feature`
-   [ ] Ensure MR title adheres to the pattern `LAN-1234: My new feature`
-   [ ] Ensure pipeline passes
-   [ ] Update documentation (README.md, comments)

### Reviewer checklist

-   [ ] Test solution locally
-   [ ] Check for typos
-   [ ] Ensure pipeline passes
-   [ ] Ensure documentation is up-to-date

---

[MR template reference](https://www.freecodecamp.org/news/why-you-should-write-merge-requests-like-youre-posting-to-instagram-765e32a3ec9c/)
